#CodeVeda Intrenship Tasks:
1- simple calculator python program 
2- scraper to scrape from www.scrapeme.live/shop
3- Python program that create a secret key and Encrypt messages
